package com.sap.hana.hadoop.samples;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WordMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	 private final static IntWritable one = new IntWritable(1);
	  private Text word = new Text();
	 private  Pattern pattern = Pattern.compile("([A-Za-z]+)");
	@Override
	protected void map(LongWritable key, Text value,
			Context context)
			throws IOException, InterruptedException {
			Matcher matcher = pattern.matcher(value.toString());
	        while (matcher.find()) {	        	
	            word.set(matcher.group(1));
	            context.write(word, one);
	        }
	}
	@Override
	public void run(Context context)
			throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("Calling super Map Run....");
		super.run(context);
		 System.out.println("Complete This Map Run....");
	}
	

	
}
